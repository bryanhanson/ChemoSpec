###################################################
### chunk number 1: 
###################################################
library(ChemoSpec) # these are only needed for the automatic vignette build, which occurs 
library(mvbutils) # in its own environment


###################################################
### chunk number 2:  eval=FALSE
###################################################
## source("My First ChemoSpec.R")


###################################################
### chunk number 3:  eval=FALSE
###################################################
## getManyCsv(gr.crit = c("sspA", "sspB"), gr.cols = c("red3", "dodgerblue4"),
## freq.unit = "ppm", int.unit = "peak intensity", descrip = "Subspecies Study",
## out.file = "subspecies")


###################################################
### chunk number 4:  eval=FALSE
###################################################
## SubspeciesNMR <- loadObject("subspecies.RData")


###################################################
### chunk number 5: 
###################################################
par(mfrow = c(2,1), mar = c(3, 1, 2, 1))
display.brewer.pal(8, "Set1")
title(main = "ChemoSpec Primary Scheme")
display.brewer.pal(8, "Set2")
title(main = "ChemoSpec Pastel Scheme")
par(mfrow = c(1,1))


###################################################
### chunk number 6:  eval=FALSE
###################################################
## sumSpectra(SubspeciesNMR)


###################################################
### chunk number 7: 
###################################################
data(CuticleIR)
sumSpectra(CuticleIR)


###################################################
### chunk number 8: 
###################################################
check4Gaps(CuticleIR$freq, CuticleIR$data[1,], plot = TRUE)


###################################################
### chunk number 9: 
###################################################
plotSpectra(CuticleIR, title = "Cuticle IR Spectra Demo",
which = c(10, 11, 40, 41, 100, 101, 140, 141, 150, 151),
yrange = c(0, 10), offset = 0.8, lab.pos = 2000)


###################################################
### chunk number 10: 
###################################################
grep("GE7", CuticleIR$names)


###################################################
### chunk number 11: 
###################################################
plotSpectra(CuticleIR, title = "Cuticle IR Spectra: Detail of Hydrocarbon Region",
which = c(10, 40, 100, 151), amplify = 10.0, xlim = c(2750, 3000),
yrange = c(0, 5), offset = 0.1, lab.pos = 2775)


###################################################
### chunk number 12: 
###################################################
noTC138 <- removeSample(CuticleIR, rem.sam = c("TC138"))
sumSpectra(noTC138)


###################################################
### chunk number 13: 
###################################################
TE2 <- grep("TE2", CuticleIR$names)
CuticleIR$names[TE2] # gives the name(s) found
TE2 # gives the corresponding indicies


###################################################
### chunk number 14: 
###################################################
newTE2 <- grep("TE2\\>",  CuticleIR$names)
CuticleIR$names[newTE2] # gives the name(s) found
newTE2 # gives the corresponding indices


###################################################
### chunk number 15: 
###################################################
specSurvey(CuticleIR, method = "iqr", title = "Cuticle IR Spectra")


###################################################
### chunk number 16: 
###################################################
noOH <- removeFreq(CuticleIR, rem.freq = CuticleIR$freq > 3100)
sumSpectra(noOH)


###################################################
### chunk number 17: 
###################################################
plotSpectra(noOH, title = "Cuticle IR Spectra, No Hydroxyl Peak?",
which = c(10, 40,  100,  140 , 150),
yrange = c(0, 5), offset = 0.8, lab.pos = 2000, xlim = c(500, 3600))


###################################################
### chunk number 18: 
###################################################
normCIR <- normSpectra(CuticleIR)


###################################################
### chunk number 19: 
###################################################
smallCIR <- binBuck(CuticleIR, bin.ratio = 4)
sumSpectra(smallCIR)


###################################################
### chunk number 20: 
###################################################
keep <- seq(1, 157, 6) # select every 6th spectrum
someCIR <- CuticleIR # make a copy of the original data
someCIR$names <- someCIR$names[keep] # modify each piece manually
someCIR$colors <- someCIR$colors[keep]
someCIR$groups <- someCIR$groups[keep]
someCIR$sym <- someCIR$sym[keep]
someCIR$alt.sym <- someCIR$alt.sym[keep]
someCIR$data <- someCIR$data[keep,] # samples in rows, freq in columns
chkSpectra(someCIR, confirm = TRUE) # make sure we didn't screw it up!
hcaSpectra(someCIR, title = "Every 6th Sample of CuticleIR")


###################################################
### chunk number 21: 
###################################################
class <- classPCA(CuticleIR, choice = "noscale")
plotScores(CuticleIR, title = "Cuticle IR Spectra", class,
pcs = c(1,2), ellipse = "rob", tol = 0.01)


###################################################
### chunk number 22: 
###################################################
robust <- robPCA(CuticleIR, choice = "noscale")
plotScores(CuticleIR, title = "Cuticle IR Spectra", robust,
pcs = c(1,2), ellipse = "rob", tol = 0.01)


###################################################
### chunk number 23: 
###################################################
diagnostics <- pcaDiag(CuticleIR, class, pcs = 2, plot = "OD")


###################################################
### chunk number 24: 
###################################################
diagnostics <- pcaDiag(CuticleIR, class, pcs = 2, plot = "SD")


###################################################
### chunk number 25: 
###################################################
plotScree(class, title = "Cuticle IR Spectra")


###################################################
### chunk number 26: 
###################################################
out <- pcaBoot(CuticleIR, pcs = 5, choice = "noscale")


###################################################
### chunk number 27:  eval=FALSE
###################################################
## plotScoresRGL(CuticleIR, class, title = "Cuticle IR Spectra",
## leg.pos = "A", t.pos = "B") # not run - it's interactive!


###################################################
### chunk number 28: 
###################################################
plotScores3D(CuticleIR, class, title = "Cuticle IR Spectra")


###################################################
### chunk number 29:  eval=FALSE
###################################################
## plotScoresG(CuticleIR, class) # not run - it's interactive!


###################################################
### chunk number 30: 
###################################################
plotLoadings(CuticleIR, class, title = "Cuticle IR Spectra",
loads = c(1, 2), ref = 1)


###################################################
### chunk number 31: 
###################################################
plot2Loadings(CuticleIR, class, title = "Cuticle IR Spectra",
loads = c(1, 2), tol = 0.002)


###################################################
### chunk number 32:  eval=FALSE
###################################################
## hcaScores(CuticleIR,  class, scores = c(1:5), title = "Cuticle IR Spectra",
## method = "complete")


###################################################
### chunk number 33: 
###################################################
data(CuticleIR)
G.only <- removeSample(CuticleIR, rem.sam = c("TE", "TC"))
G.only <- conColScheme(G.only, new = c("red", "blue"))
sumSpectra(G.only)


###################################################
### chunk number 34:  eval=FALSE
###################################################
## mclust3dSpectra(G.only, G.only.pca) # not run - it's interactive!


###################################################
### chunk number 35: 
###################################################
G.only.pca <- classPCA(G.only)
plotScores(G.only, G.only.pca, title = "Two Genotypes (Controls)",
ellipse = "rob")


###################################################
### chunk number 36: 
###################################################
model <- mclustSpectra(G.only, G.only.pca, plot = "BIC",
title = "Two Genotypes (Controls)")


###################################################
### chunk number 37: 
###################################################
model <- mclustSpectra(G.only, G.only.pca, plot = "proj",
title = "Two Genotypes (Controls)")


###################################################
### chunk number 38: 
###################################################
model <- mclustSpectra(G.only, G.only.pca, plot = "errors",
title = "Two Genotypes (Controls)", truth = G.only$groups)


###################################################
### chunk number 39: 
###################################################
foodweb(where = "package:ChemoSpec", charlim = 30, cex = 0.75, lwd = 1)


