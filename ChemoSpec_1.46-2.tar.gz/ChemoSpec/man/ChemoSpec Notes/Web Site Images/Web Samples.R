
# Script to produce plots for the ChemoSpec
# graph gallery

data(CuticleIR)

png("spectra.png", width = 1000, height = 750)
plotSpectra(CuticleIR, title = "Cuticle IR Spectra Genotype X Treatment", which = c(1, 30, 80, 150),
	yrange = c(0, 40), xrange = c(3600, 500), offset = 1, lab.pos = 2000, amplify = 10)
dev.off()

results <- classPCA(CuticleIR, choice = "noscale")

png("scree.png", width = 1000, height = 750)
plotScree(results, title = "Cuticle IR Spectra")
dev.off()

png("3Dscores.png", width = 1000, height = 750)
plotScores3D(CuticleIR, results, title = "Cuticle IR Spectra")
dev.off()


png("classical scores.png", width = 1000, height = 750)
plotScores(CuticleIR, title = "Cuticle IR Spectra", results, pcs = c(1,2), ellipse = "rob", tol = 0.01)
dev.off()

png("loadings.png", width = 1000, height = 750)
plotLoadings(CuticleIR, results, title = "Cuticle IR Spectra", loads = c(1, 2), ref = 1, xlim = c(3600, 500))
dev.off()

png("twoloadings.png", width = 750, height = 750)
plot2Loadings(CuticleIR, title = "Cuticle IR Spectra", results, loads = c(1,2), tol = 0.0)
dev.off()

png("boot.png", width = 750, height = 750)
temp <- pcaBoot(CuticleIR, pcs = 5, choice = "noscale")
dev.off()

png("diagnostics.png", width = 1000, height = 750)
temp <- pcaDiag(CuticleIR, results, pcs = 2, plot = "SD")
dev.off()

png("HCA.png", width = 1000, height = 750)
HCA(CuticleIR, title = "Cuticle IR Spectra", method = "complete")
dev.off()

results <- robPCA(CuticleIR, choice = "mad")
png("robust scores.png", width = 1000, height = 750)
plotScores(CuticleIR, title = "Cuticle IR Spectra", results, pcs = c(1,2), ellipse = "rob", tol = 0.05)
dev.off()

