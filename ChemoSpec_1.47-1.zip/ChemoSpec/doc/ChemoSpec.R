### R code from vignette source 'ChemoSpec.Rnw'

###################################################
### code chunk number 1: SetUp
###################################################
library(ChemoSpec) # these are only needed for the automatic vignette build, which occurs 
library(mvbutils) # in a clean environment
if (!file.exists("graphics")) dir.create("graphics")


###################################################
### code chunk number 2: Chunk1 (eval = FALSE)
###################################################
## source("My First ChemoSpec.R")


###################################################
### code chunk number 3: Chunk2 (eval = FALSE)
###################################################
## getManyCsv(gr.crit = c("sspA", "sspB"), gr.cols = c("red3", "dodgerblue4"),
## freq.unit = "ppm", int.unit = "peak intensity", descrip = "Subspecies Study",
## out.file = "subspecies")


###################################################
### code chunk number 4: Chunk3 (eval = FALSE)
###################################################
## SubspeciesNMR <- loadObject("subspecies.RData")


###################################################
### code chunk number 5: Chunk4
###################################################
par(mfrow = c(2,1), mar = c(3, 1, 2, 1))
display.brewer.pal(8, "Set1")
title(main = "ChemoSpec Primary Scheme")
display.brewer.pal(8, "Set2")
title(main = "ChemoSpec Pastel Scheme")
par(mfrow = c(1,1))


###################################################
### code chunk number 6: Chunk5 (eval = FALSE)
###################################################
## sumSpectra(SubspeciesNMR)


###################################################
### code chunk number 7: Chunk6
###################################################
data(CuticleIR) # makes the data available
sumSpectra(CuticleIR)


###################################################
### code chunk number 8: Chunk7
###################################################
check4Gaps(CuticleIR$freq, CuticleIR$data[1,], plot = TRUE)


###################################################
### code chunk number 9: Chunk8
###################################################
plotSpectra(CuticleIR, title = "Cuticle IR Spectra Demo",
which = c(10, 11, 40, 41, 100, 101, 140, 141, 150, 151),
yrange = c(0, 10), offset = 0.8, lab.pos = 2000)


###################################################
### code chunk number 10: Chunk9
###################################################
grep("GE7", CuticleIR$names)


###################################################
### code chunk number 11: Chunk10
###################################################
plotSpectra(CuticleIR, title = "Cuticle IR Spectra: Detail of Hydrocarbon Region",
which = c(10, 40, 100, 151), amplify = 10.0, xlim = c(2750, 3000),
yrange = c(0, 5), offset = 0.1, lab.pos = 2775)


###################################################
### code chunk number 12: Chunk11
###################################################
noTC138 <- removeSample(CuticleIR, rem.sam = c("TC138"))
sumSpectra(noTC138)


###################################################
### code chunk number 13: Chunk12
###################################################
TE2 <- grep("TE2", CuticleIR$names)
CuticleIR$names[TE2] # gives the name(s) that contain "TE2"
TE2 # gives the corresponding indicies


###################################################
### code chunk number 14: Chunk13
###################################################
newTE2 <- grep("TE2\\>",  CuticleIR$names)
CuticleIR$names[newTE2] # gives the name(s) found
newTE2 # gives the corresponding indices


###################################################
### code chunk number 15: Chunk14
###################################################
specSurvey(CuticleIR, method = "iqr", title = "Cuticle IR Spectra")


###################################################
### code chunk number 16: Chunk15
###################################################
noOH <- removeFreq(CuticleIR, rem.freq = CuticleIR$freq > 3100)
sumSpectra(noOH)


###################################################
### code chunk number 17: Chunk16
###################################################
plotSpectra(noOH, title = "Cuticle IR Spectra, No Hydroxyl Peak?",
which = c(10, 40,  100,  140 , 150),
yrange = c(0, 5), offset = 0.8, lab.pos = 2000, xlim = c(500, 3600))


###################################################
### code chunk number 18: Chunk17
###################################################
normCIR <- normSpectra(CuticleIR)


###################################################
### code chunk number 19: Chunk19
###################################################
keep <- seq(1, 157, 6) # select every 6th spectrum
someCIR <- CuticleIR # make a copy of the original data
someCIR$names <- someCIR$names[keep] # modify each piece manually
someCIR$colors <- someCIR$colors[keep]
someCIR$groups <- someCIR$groups[keep]
someCIR$sym <- someCIR$sym[keep]
someCIR$alt.sym <- someCIR$alt.sym[keep]
someCIR$data <- someCIR$data[keep,] # samples in rows, freq in columns
chkSpectra(someCIR, confirm = TRUE) # make sure we didn't screw it up!
hcaSpectra(someCIR, title = "Every 6th Sample of CuticleIR")


###################################################
### code chunk number 20: Chunk10
###################################################
class <- classPCA(CuticleIR, choice = "noscale")
plotScores(CuticleIR, title = "Cuticle IR Spectra", class,
pcs = c(1,2), ellipse = "rob", tol = 0.01)


###################################################
### code chunk number 21: Chunk21
###################################################
robust <- robPCA(CuticleIR, choice = "noscale")
plotScores(CuticleIR, title = "Cuticle IR Spectra", robust,
pcs = c(1,2), ellipse = "rob", tol = 0.01)


###################################################
### code chunk number 22: Chunk22
###################################################
diagnostics <- pcaDiag(CuticleIR, class, pcs = 2, plot = "OD")


###################################################
### code chunk number 23: Chunk23
###################################################
diagnostics <- pcaDiag(CuticleIR, class, pcs = 2, plot = "SD")


###################################################
### code chunk number 24: Chunk24
###################################################
plotScree(class, title = "Cuticle IR Spectra")


###################################################
### code chunk number 25: Chunk25
###################################################
out <- pcaBoot(CuticleIR, pcs = 5, choice = "noscale")


###################################################
### code chunk number 26: Chunk26 (eval = FALSE)
###################################################
## plotScoresRGL(CuticleIR, class, title = "Cuticle IR Spectra",
## leg.pos = "A", t.pos = "B") # not run - it's interactive!


###################################################
### code chunk number 27: Chunk27
###################################################
plotScores3D(CuticleIR, class, title = "Cuticle IR Spectra")


###################################################
### code chunk number 28: Chunk28 (eval = FALSE)
###################################################
## plotScoresG(CuticleIR, class) # not run - it's interactive!


###################################################
### code chunk number 29: Chunk29
###################################################
plotLoadings(CuticleIR, class, title = "Cuticle IR Spectra",
loads = c(1, 2), ref = 1)


###################################################
### code chunk number 30: Chunk30
###################################################
plot2Loadings(CuticleIR, class, title = "Cuticle IR Spectra",
loads = c(1, 2), tol = 0.002)


###################################################
### code chunk number 31: Chunk30a
###################################################
spt <- sPlotSpectra(CuticleIR, class, title = "Cuticle IR Spectra", pc = 1)


###################################################
### code chunk number 32: Chunk31 (eval = FALSE)
###################################################
## hcaScores(CuticleIR,  class, scores = c(1:5), title = "Cuticle IR Spectra",
## method = "complete")


###################################################
### code chunk number 33: Chunk30b
###################################################
# Split the existing "groups" element of the Spectra object
# into two new factors with two levels each
n.groups <-list(genotype = c("G", "T"), treatment = c("C", "E"))
NewIR <- splitSpectraGroups(CuticleIR, n.groups)
# run aovPCA & plot the first score plot
mats <-aovPCA(NewIR, fac = c("genotype", "treatment"))
apca1 <- aovPCAscores(NewIR, mats, plot = 1, ellipse = "rob")


###################################################
### code chunk number 34: Chunk32
###################################################
data(CuticleIR)
G.only <- removeSample(CuticleIR, rem.sam = c("TE", "TC"))
G.only <- conColScheme(G.only, new = c("red", "blue"))
sumSpectra(G.only)


###################################################
### code chunk number 35: Chunk33 (eval = FALSE)
###################################################
## mclust3dSpectra(G.only, G.only.pca) # not run - it's interactive!


###################################################
### code chunk number 36: Chunk34
###################################################
G.only.pca <- classPCA(G.only)
plotScores(G.only, G.only.pca, title = "Two Genotypes (Controls)",
ellipse = "rob")


###################################################
### code chunk number 37: Chunk35
###################################################
model <- mclustSpectra(G.only, G.only.pca, plot = "BIC",
title = "Two Genotypes (Controls)")


###################################################
### code chunk number 38: Chunk36
###################################################
model <- mclustSpectra(G.only, G.only.pca, plot = "proj",
title = "Two Genotypes (Controls)")


###################################################
### code chunk number 39: Chunk37
###################################################
model <- mclustSpectra(G.only, G.only.pca, plot = "errors",
title = "Two Genotypes (Controls)", truth = G.only$groups)


###################################################
### code chunk number 40: Chunk38
###################################################
require(mvbutils)
foodweb(where = "package:ChemoSpec", charlim = 30, cex = 0.75, lwd = 1)


