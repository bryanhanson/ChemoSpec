	
seXyIqr <- function(x) {
	i <- fivenum(x)
	c(y = i[3], ymin = i[2], ymax = i[4])
	}
	

