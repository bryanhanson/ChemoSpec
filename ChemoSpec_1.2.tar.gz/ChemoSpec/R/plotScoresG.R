

plotScoresG <-
function(spectra, pca, pcs = c(1:3), scheme = "primary")
	{

# Function to plot PCA scores using ggobi
# Part of the ChemoSpec package
# Bryan Hanson, DePauw University, Oct 2009

	chkSpectra(spectra)

	# set up the data frame properly labeled
	
	len <- length(pcs)
	data <- data.frame(pca$x[,pcs[1]])
	for (i in 2:len) data <- cbind(data, pca$x[,pcs[i]])

	eigensum <- sum(pca$sdev*pca$sdev) # prepare labels
	variance <- 100*(pca$sdev*pca$sdev/eigensum)
	pc.name <- c()
	for (i in 1:len) {
		pc.name[i] <- paste("PC", pcs[i], " (", format(variance[i], digits=2),
		"%", ")", sep = "")
		}
	names(data) <- pc.name

	# Fix color scheme: GGobi does not accept just any color scheme
	# Have to match existing color scheme to one ggobi can use.
	# Max number of groups is 8, we'll use only what we need.
	# Users probably want a consistent color scheme throughout,
	# so the note in getManyCsv about colors is important

	colors <- spectra$colors
	col.lev <- levels(as.factor(colors))	
	no.col <- length(col.lev)
	col.nos <- c(1:8)
	if (no.col > 8) stop("ggobi can only display 8 different groups")
	
	for (n in 1:no.col) {
		which <- grep(col.lev[n], colors)
		colors[which] <- col.nos[n]		
		}
	
	if (scheme == "primary") {
		col.names <- c("red3", "dodgerblue4", "forestgreen", "purple4",
		"orangered", "yellow", "orangered4", "violetred2")
		}
	if (scheme == "pastel") {
		col.names <- c("seagreen", "brown2", "skyblue2", "hotpink3",
		"chartreuse3", "darkgoldenrod2", "lightsalmon3", "gray48")		}
	
	cat("Colors have been mapped as follows:\n")	
	for (n in 1:no.col) {
		cat("Original Color: ", col.lev[n], "New Color: ", col.names[n], "\n")
		}
	

	S1 <- ggobi(data)
	if (scheme == "primary") colorscheme(S1) <- "Set1 8"
	if (scheme == "pastel") colorscheme(S1) <- "Set2 8"
	glyph_color(S1[1]) <- colors

	}
